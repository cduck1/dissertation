var recordData = [
  {
    "length": 205535,
    "seq_id": "c00001_gnlPro..",
    "regions": []
  },
  {
    "length": 51841,
    "seq_id": "c00002_gnlPro..",
    "regions": []
  },
  {
    "length": 45120,
    "seq_id": "c00003_gnlPro..",
    "regions": []
  },
  {
    "length": 43295,
    "seq_id": "c00004_gnlPro..",
    "regions": []
  },
  {
    "length": 41253,
    "seq_id": "c00005_gnlPro..",
    "regions": []
  },
  {
    "length": 38917,
    "seq_id": "c00006_gnlPro..",
    "regions": []
  },
  {
    "length": 34092,
    "seq_id": "c00007_gnlPro..",
    "regions": []
  },
  {
    "length": 31733,
    "seq_id": "c00008_gnlPro..",
    "regions": []
  },
  {
    "length": 31489,
    "seq_id": "c00009_gnlPro..",
    "regions": []
  },
  {
    "length": 30122,
    "seq_id": "c00010_gnlPro..",
    "regions": []
  },
  {
    "length": 30046,
    "seq_id": "c00011_gnlPro..",
    "regions": []
  },
  {
    "length": 168916,
    "seq_id": "c00012_gnlPro..",
    "regions": []
  },
  {
    "length": 28380,
    "seq_id": "c00013_gnlPro..",
    "regions": []
  },
  {
    "length": 26223,
    "seq_id": "c00014_gnlPro..",
    "regions": []
  },
  {
    "length": 24418,
    "seq_id": "c00015_gnlPro..",
    "regions": []
  },
  {
    "length": 23896,
    "seq_id": "c00016_gnlPro..",
    "regions": []
  },
  {
    "length": 21985,
    "seq_id": "c00017_gnlPro..",
    "regions": []
  },
  {
    "length": 20906,
    "seq_id": "c00018_gnlPro..",
    "regions": []
  },
  {
    "length": 19831,
    "seq_id": "c00019_gnlPro..",
    "regions": []
  },
  {
    "length": 19500,
    "seq_id": "c00020_gnlPro..",
    "regions": []
  },
  {
    "length": 19291,
    "seq_id": "c00021_gnlPro..",
    "regions": []
  },
  {
    "length": 19287,
    "seq_id": "c00022_gnlPro..",
    "regions": []
  },
  {
    "length": 146692,
    "seq_id": "c00023_gnlPro..",
    "regions": []
  },
  {
    "length": 18072,
    "seq_id": "c00024_gnlPro..",
    "regions": []
  },
  {
    "length": 16585,
    "seq_id": "c00025_gnlPro..",
    "regions": []
  },
  {
    "length": 16167,
    "seq_id": "c00026_gnlPro..",
    "regions": []
  },
  {
    "length": 15972,
    "seq_id": "c00027_gnlPro..",
    "regions": []
  },
  {
    "length": 15916,
    "seq_id": "c00028_gnlPro..",
    "regions": []
  },
  {
    "length": 15049,
    "seq_id": "c00029_gnlPro..",
    "regions": []
  },
  {
    "length": 14716,
    "seq_id": "c00030_gnlPro..",
    "regions": []
  },
  {
    "length": 14699,
    "seq_id": "c00031_gnlPro..",
    "regions": []
  },
  {
    "length": 14298,
    "seq_id": "c00032_gnlPro..",
    "regions": []
  },
  {
    "length": 13699,
    "seq_id": "c00033_gnlPro..",
    "regions": []
  },
  {
    "length": 75052,
    "seq_id": "c00034_gnlPro..",
    "regions": []
  },
  {
    "length": 13388,
    "seq_id": "c00035_gnlPro..",
    "regions": []
  },
  {
    "length": 12368,
    "seq_id": "c00036_gnlPro..",
    "regions": []
  },
  {
    "length": 12315,
    "seq_id": "c00037_gnlPro..",
    "regions": []
  },
  {
    "length": 11896,
    "seq_id": "c00038_gnlPro..",
    "regions": []
  },
  {
    "length": 10984,
    "seq_id": "c00039_gnlPro..",
    "regions": []
  },
  {
    "length": 10126,
    "seq_id": "c00040_gnlPro..",
    "regions": []
  },
  {
    "length": 9672,
    "seq_id": "c00041_gnlPro..",
    "regions": []
  },
  {
    "length": 9347,
    "seq_id": "c00042_gnlPro..",
    "regions": []
  },
  {
    "length": 8888,
    "seq_id": "c00043_gnlPro..",
    "regions": []
  },
  {
    "length": 8507,
    "seq_id": "c00044_gnlPro..",
    "regions": []
  },
  {
    "length": 73735,
    "seq_id": "c00045_gnlPro..",
    "regions": []
  },
  {
    "length": 8396,
    "seq_id": "c00046_gnlPro..",
    "regions": []
  },
  {
    "length": 7982,
    "seq_id": "c00047_gnlPro..",
    "regions": []
  },
  {
    "length": 7418,
    "seq_id": "c00048_gnlPro..",
    "regions": []
  },
  {
    "length": 7383,
    "seq_id": "c00049_gnlPro..",
    "regions": []
  },
  {
    "length": 6648,
    "seq_id": "c00050_gnlPro..",
    "regions": []
  },
  {
    "length": 6278,
    "seq_id": "c00051_gnlPro..",
    "regions": []
  },
  {
    "length": 5781,
    "seq_id": "c00052_gnlPro..",
    "regions": []
  },
  {
    "length": 5194,
    "seq_id": "c00053_gnlPro..",
    "regions": []
  },
  {
    "length": 5072,
    "seq_id": "c00054_gnlPro..",
    "regions": []
  },
  {
    "length": 4453,
    "seq_id": "c00055_gnlPro..",
    "regions": []
  },
  {
    "length": 63162,
    "seq_id": "c00056_gnlPro..",
    "regions": []
  },
  {
    "length": 4350,
    "seq_id": "c00057_gnlPro..",
    "regions": []
  },
  {
    "length": 4265,
    "seq_id": "c00058_gnlPro..",
    "regions": []
  },
  {
    "length": 3201,
    "seq_id": "c00059_gnlPro..",
    "regions": []
  },
  {
    "length": 3139,
    "seq_id": "c00060_gnlPro..",
    "regions": []
  },
  {
    "length": 2961,
    "seq_id": "c00061_gnlPro..",
    "regions": []
  },
  {
    "length": 2948,
    "seq_id": "c00062_gnlPro..",
    "regions": []
  },
  {
    "length": 2834,
    "seq_id": "c00063_gnlPro..",
    "regions": []
  },
  {
    "length": 2557,
    "seq_id": "c00064_gnlPro..",
    "regions": []
  },
  {
    "length": 2519,
    "seq_id": "c00065_gnlPro..",
    "regions": []
  },
  {
    "length": 2263,
    "seq_id": "c00066_gnlPro..",
    "regions": []
  },
  {
    "length": 62994,
    "seq_id": "c00067_gnlPro..",
    "regions": []
  },
  {
    "length": 2209,
    "seq_id": "c00068_gnlPro..",
    "regions": []
  },
  {
    "length": 2173,
    "seq_id": "c00069_gnlPro..",
    "regions": []
  },
  {
    "length": 1943,
    "seq_id": "c00070_gnlPro..",
    "regions": []
  },
  {
    "length": 1779,
    "seq_id": "c00071_gnlPro..",
    "regions": []
  },
  {
    "length": 1587,
    "seq_id": "c00072_gnlPro..",
    "regions": []
  },
  {
    "length": 1578,
    "seq_id": "c00073_gnlPro..",
    "regions": []
  },
  {
    "length": 1362,
    "seq_id": "c00074_gnlPro..",
    "regions": []
  },
  {
    "length": 1351,
    "seq_id": "c00075_gnlPro..",
    "regions": []
  },
  {
    "length": 1304,
    "seq_id": "c00076_gnlPro..",
    "regions": []
  },
  {
    "length": 1265,
    "seq_id": "c00077_gnlPro..",
    "regions": []
  },
  {
    "length": 56514,
    "seq_id": "c00078_gnlPro..",
    "regions": []
  },
  {
    "length": 1236,
    "seq_id": "c00079_gnlPro..",
    "regions": []
  },
  {
    "length": 1115,
    "seq_id": "c00080_gnlPro..",
    "regions": []
  },
  {
    "length": 1110,
    "seq_id": "c00081_gnlPro..",
    "regions": []
  },
  {
    "length": 1012,
    "seq_id": "c00082_gnlPro..",
    "regions": []
  },
  {
    "length": 53350,
    "seq_id": "c00083_gnlPro..",
    "regions": []
  }
];
var all_regions = {
  "order": []
};
var details_data = {};
